
public class Music {
    Release release;
    Artist  artist;
    Song    song;
    Music()
    {
       
    }
}

