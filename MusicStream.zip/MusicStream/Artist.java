

public class Artist {
    Float terms_freq;
    String terms;
    String name;
    Float familiarity;
    Float longitude;
    String id;
    String location;
    Float latitude;
    String similar;
    Float hotttnesss;
    Artist()
    {
        terms_freq= 0.0f;
        terms = "";
        name = "";
        familiarity = 0.0f;
        longitude = 0.0f;
        id = "";
        location = "";
        latitude = 0.0f;
        similar = "";
        hotttnesss = 0.0f;
    }
}

