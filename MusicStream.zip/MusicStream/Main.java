import java.io.IOException;
import java.io.InputStream;
import java.io.FileReader;

import java.io.FileNotFoundException;
import javazoom.jl.player.*;
import javazoom.jl.decoder.JavaLayerException;
import com.google.gson.Gson;
import com.google.gson.Gson;



public class Main {
   
      /**
     * Play a given audio file.
     * @param audioFilePath Path of the audio file.
     */
    void mp3play(String file) {
        try {
            // It uses CECS327InputStream as InputStream to play the song 
             InputStream is = new CECS327InputStream(file);
             Player mp3player = new Player(is);
             mp3player.play();
	}
	catch (JavaLayerException ex) {
	    ex.printStackTrace();
	}
	catch (IOException ex) {
            System.out.println("Error playing the audio file.");
            ex.printStackTrace();
        }
    }
     
     
    public static void main(String[] args) {
        Integer i;
        Gson gson = new Gson();
        
        try 
        {
            Music[] music = gson.fromJson(new FileReader("music.json"), Music[].class);

            for (i=0; i<music.length; i++)
            {
                if (music[i].song.title.startsWith("The Imperial March from"))
                {
                    System.out.println("Playing " + music[i].song.title);
                    Main player = new Main();
                    player.mp3play(music[i].song.id);
                    System.out.println("End of the song");
                }
            }
        }
        catch (FileNotFoundException ex)
        {
            System.out.println("Cannot read Json file.");
            ex.printStackTrace();
        }
        
    }
 
}

