



public class Release {
    Integer id;
    String name; 
    Release()
    {
        id = 0;
        name = "";
    }
}

